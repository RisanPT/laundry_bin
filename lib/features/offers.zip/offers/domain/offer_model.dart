class OfferModel {
  bool isSelected;
  String title;
  String icon;

  OfferModel({
    required this.isSelected,
    required this.title,
    required this.icon,
  });
}
